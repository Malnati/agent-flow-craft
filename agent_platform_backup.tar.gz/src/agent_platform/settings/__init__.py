# Importar configurações comuns e específicas
from .common import *
from .agents import *
